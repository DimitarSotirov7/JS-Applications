function errorHandler(error) {
    console.log(error.message);
}

export default errorHandler;